<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        // echo "1st PHP ";
        $x=5;
        $y=4;
         $z=$x+$y;
         echo "The addition is:$z";
    ?>
</body>
</html>